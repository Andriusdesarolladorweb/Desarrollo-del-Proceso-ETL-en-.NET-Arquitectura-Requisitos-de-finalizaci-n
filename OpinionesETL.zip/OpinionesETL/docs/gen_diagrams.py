"""Genera los diagramas (draw.io editable + PNG) desde una sola definición."""
import html
import sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Ellipse, Rectangle, Polygon, FancyArrowPatch

OUT = sys.argv[1] if len(sys.argv) > 1 else "."

C = {  # fill, stroke
    "src": ("#E8EEF7", "#4A6FA5"),
    "worker": ("#FFF4E0", "#D08A1E"),
    "app": ("#EAF5EA", "#3C8D3C"),
    "infra": ("#E6F2FA", "#2E75B6"),
    "domain": ("#F3E8F7", "#7B4A9A"),
    "out": ("#E9F6F1", "#2C8C6A"),
    "next": ("#F5F5F5", "#9A9A9A"),
    "cfg": ("#FDECEC", "#B84A4A"),
    "group": ("#FFFFFF", "#555555"),
    "term": ("#DDEBF7", "#2E75B6"),
    "step": ("#FFFFFF", "#2E75B6"),
    "dec": ("#FFF4E0", "#D08A1E"),
    "bad": ("#FDECEC", "#B84A4A"),
}


class Diagram:
    def __init__(self, name, w, h):
        self.name, self.w, self.h = name, w, h
        self.nodes, self.edges = [], []

    def node(self, nid, label, x, y, w, h, kind, shape="rect", fs=10, bold=False, valign="middle"):
        self.nodes.append(dict(id=nid, label=label, x=x, y=y, w=w, h=h, kind=kind, shape=shape, fs=fs, bold=bold, valign=valign))
        return nid

    def edge(self, a, b, label="", dashed=False, pts=None, sa=None, ta=None):
        self.edges.append(dict(a=a, b=b, label=label, dashed=dashed, pts=pts or [], sa=sa, ta=ta))

    # ---------------- draw.io ----------------
    def drawio(self):
        cells = ['<mxCell id="0"/>', '<mxCell id="1" parent="0"/>']
        for n in self.nodes:
            fill, stroke = C[n["kind"]]
            base = {
                "rect": "rounded=1;arcSize=8;whiteSpace=wrap;html=1;",
                "group": "rounded=1;arcSize=3;whiteSpace=wrap;html=1;dashed=1;verticalAlign=top;",
                "layer": "rounded=1;arcSize=4;whiteSpace=wrap;html=1;verticalAlign=top;align=left;spacingLeft=8;",
                "db": "shape=cylinder3;whiteSpace=wrap;html=1;boundedLbl=1;size=10;",
                "doc": "shape=document;whiteSpace=wrap;html=1;boundedLbl=1;size=0.15;",
                "cloud": "ellipse;shape=cloud;whiteSpace=wrap;html=1;",
                "diamond": "rhombus;whiteSpace=wrap;html=1;",
                "term": "rounded=1;arcSize=50;whiteSpace=wrap;html=1;",
                "text": "text;html=1;align=center;verticalAlign=middle;",
            }[n["shape"]]
            style = f"{base}fillColor={fill};strokeColor={stroke};fontSize={n['fs']};" + ("fontStyle=1;" if n["bold"] else "")
            if n["shape"] == "text":
                style = f"{base}fontSize={n['fs']};fontColor={stroke};" + ("fontStyle=1;" if n["bold"] else "")
            lab = html.escape(n["label"]).replace("\n", "&lt;br&gt;")
            cells.append(f'<mxCell id="{n["id"]}" value="{lab}" style="{style}" vertex="1" parent="1">'
                         f'<mxGeometry x="{n["x"]}" y="{n["y"]}" width="{n["w"]}" height="{n["h"]}" as="geometry"/></mxCell>')
        for i, e in enumerate(self.edges):
            style = "edgeStyle=orthogonalEdgeStyle;rounded=1;html=1;endArrow=block;endFill=1;strokeColor=#444444;fontSize=9;"
            if e["dashed"]:
                style += "dashed=1;"
            pts = "".join(f'<mxPoint x="{x}" y="{y}"/>' for x, y in e["pts"])
            arr = f'<Array as="points">{pts}</Array>' if pts else ""
            lab = html.escape(e["label"])
            cells.append(f'<mxCell id="e{i}" value="{lab}" style="{style}" edge="1" parent="1" source="{e["a"]}" target="{e["b"]}">'
                         f'<mxGeometry relative="1" as="geometry">{arr}</mxGeometry></mxCell>')
        xml = (f'<mxfile host="app.diagrams.net"><diagram name="{self.name}"><mxGraphModel dx="1200" dy="800" grid="1" gridSize="10" '
               f'page="1" pageWidth="{self.w}" pageHeight="{self.h}"><root>{"".join(cells)}</root></mxGraphModel></diagram></mxfile>')
        return xml

    # ---------------- PNG ----------------
    def _n(self, nid):
        return next(n for n in self.nodes if n["id"] == nid)

    @staticmethod
    def _anchor(n, toward):
        cx, cy = n["x"] + n["w"] / 2, n["y"] + n["h"] / 2
        tx, ty = toward
        dx, dy = tx - cx, ty - cy
        if dx == 0 and dy == 0:
            return cx, cy
        if abs(dx) * n["h"] > abs(dy) * n["w"]:
            return (n["x"] + n["w"] if dx > 0 else n["x"]), cy
        return cx, (n["y"] + n["h"] if dy > 0 else n["y"])

    def png(self, out_path, scale=0.01):
        fig = plt.figure(figsize=(self.w * scale, self.h * scale), dpi=200)
        ax = fig.add_axes([0, 0, 1, 1])
        ax.set_xlim(0, self.w); ax.set_ylim(self.h, 0); ax.axis("off")
        order = {"group": 0, "layer": 1}
        for n in sorted(self.nodes, key=lambda n: order.get(n["shape"], 2)):
            fill, stroke = C[n["kind"]]
            x, y, w, h = n["x"], n["y"], n["w"], n["h"]
            s = n["shape"]
            if s in ("rect", "layer", "group", "term"):
                pad = min(w, h) * (0.5 if s == "term" else 0.08 if s == "rect" else 0.02)
                ax.add_patch(FancyBboxPatch((x + pad, y + pad), w - 2 * pad, h - 2 * pad,
                             boxstyle=f"round,pad={pad}", fc=fill, ec=stroke, lw=1.4,
                             ls="--" if s == "group" else "-"))
            elif s == "db":
                e = 14
                ax.add_patch(Rectangle((x, y + e / 2), w, h - e, fc=fill, ec="none"))
                ax.plot([x, x], [y + e / 2, y + h - e / 2], color=stroke, lw=1.4)
                ax.plot([x + w, x + w], [y + e / 2, y + h - e / 2], color=stroke, lw=1.4)
                ax.add_patch(Ellipse((x + w / 2, y + h - e / 2), w, e, fc=fill, ec=stroke, lw=1.4))
                ax.add_patch(Ellipse((x + w / 2, y + e / 2), w, e, fc=fill, ec=stroke, lw=1.4))
            elif s == "doc":
                import numpy as np
                xs = np.linspace(x, x + w, 40)
                ys = y + h - 6 + 6 * np.sin((xs - x) / w * 2 * np.pi)
                poly = [(x, y), (x + w, y)] + list(zip(xs[::-1], ys[::-1]))
                ax.add_patch(Polygon(poly, closed=True, fc=fill, ec=stroke, lw=1.4))
            elif s == "cloud":
                ax.add_patch(Ellipse((x + w / 2, y + h / 2), w, h, fc=fill, ec=stroke, lw=1.4))
            elif s == "diamond":
                ax.add_patch(Polygon([(x + w / 2, y), (x + w, y + h / 2), (x + w / 2, y + h), (x, y + h / 2)],
                                     closed=True, fc=fill, ec=stroke, lw=1.4))
            tx = x + (10 if s == "layer" else w / 2)
            ha = "left" if s == "layer" else "center"
            if s in ("group", "layer") or n["valign"] == "top":
                ty, va = y + 8, "top"
            else:
                ty, va = y + h / 2, "center"
            ax.text(tx, ty, n["label"], ha=ha, va=va, fontsize=n["fs"] * 0.62,
                    fontweight="bold" if n["bold"] else "normal",
                    color=stroke if s in ("text", "group", "layer") else "#1F1F1F", linespacing=1.25, zorder=5)
        for e in self.edges:
            a, b = self._n(e["a"]), self._n(e["b"])
            pts = e["pts"]
            first_t = pts[0] if pts else (b["x"] + b["w"] / 2, b["y"] + b["h"] / 2)
            last_f = pts[-1] if pts else (a["x"] + a["w"] / 2, a["y"] + a["h"] / 2)
            p0 = e["sa"] or self._anchor(a, first_t)
            p1 = e["ta"] or self._anchor(b, last_f)
            path = [p0] + pts + [p1]
            ls = (0, (4, 3)) if e["dashed"] else "-"
            for (x0, y0), (x1, y1) in zip(path[:-2], path[1:-1]):
                ax.plot([x0, x1], [y0, y1], color="#444444", lw=1.1, ls=ls, zorder=3)
            ax.add_patch(FancyArrowPatch(path[-2], path[-1], arrowstyle="-|>", mutation_scale=9,
                                         color="#444444", lw=1.1, ls=ls, zorder=3))
            if e["label"]:
                mx = (path[0][0] + path[1][0]) / 2 if len(path) == 2 else path[1][0]
                my = (path[0][1] + path[1][1]) / 2 if len(path) == 2 else path[1][1]
                ax.text(mx, my - 5, e["label"], fontsize=5.6, ha="center", va="bottom", color="#333333",
                        bbox=dict(fc="white", ec="none", pad=0.6), zorder=6)
        fig.savefig(out_path, dpi=200, facecolor="white")
        plt.close(fig)


# ===================== Diagrama de arquitectura =====================
A = Diagram("Arquitectura", 1240, 760)
A.node("t", "Arquitectura del proceso ETL: análisis de opiniones de clientes", 20, 10, 1200, 30, "group", "text", fs=16, bold=True)

A.node("gsrc", "Fuentes de datos", 20, 60, 200, 470, "group", "group", fs=12, bold=True)
A.node("csv", "Encuestas internas\nsurveys.csv", 40, 110, 160, 80, "src", "doc")
A.node("sql", "SQL Server\nOpinionesFuenteDB\n(dbo.WebReviews)", 40, 240, 160, 100, "src", "db")
A.node("api", "API REST\nComentarios redes\n(HTTPS + API Key)", 40, 400, 160, 90, "src", "cloud")

A.node("gw", "Servicio ETL: Worker Service (.NET 8), Clean Architecture", 250, 60, 640, 590, "group", "group", fs=12, bold=True)
A.node("lw", "Capa Worker (Host)", 270, 95, 600, 85, "worker", "layer", fs=10, bold=True)
A.node("worker", "Worker : BackgroundService\nPeriodicTimer / RunOnce", 290, 120, 260, 50, "worker")
A.node("di", "Program.cs\nInyección de dependencias", 590, 120, 260, 50, "worker")

A.node("la", "Capa Application (casos de uso y contratos)", 270, 195, 600, 105, "app", "layer", fs=10, bold=True)
A.node("svc", "ExtractionService\nParallel.ForEachAsync", 290, 225, 175, 60, "app")
A.node("base", "ExtractorBase<T>\nStopwatch + ILogger", 480, 225, 175, 60, "app")
A.node("ifaces", "IExtractor · IStagingWriter\nIDataLoader", 670, 225, 180, 60, "app")

A.node("li", "Capa Infrastructure (implementaciones)", 270, 315, 600, 215, "infra", "layer", fs=10, bold=True)
A.node("csvx", "CsvExtractor\n(CsvHelper)", 290, 345, 175, 55, "infra")
A.node("dbx", "DatabaseExtractor\n(ADO.NET)", 290, 410, 175, 55, "infra")
A.node("apix", "ApiExtractor\n(IHttpClientFactory)", 290, 470, 175, 50, "infra")
A.node("retry", "RetryHandler\n(reintentos exponenciales)", 480, 470, 175, 50, "infra")
A.node("conn", "SqlConnectionFactory", 480, 410, 175, 55, "infra")
A.node("stw", "JsonFileStagingWriter\n(escritura en streaming)", 670, 345, 180, 55, "infra")
A.node("loader", "DataLoader\n(próxima fase: T y L)", 670, 430, 180, 55, "next")

A.node("ld", "Capa Domain", 270, 545, 600, 90, "domain", "layer", fs=10, bold=True)
A.node("ent", "Entidades: SurveyResponse · WebReview · SocialComment", 290, 572, 360, 50, "domain")
A.node("res", "ExtractionResult\n(métricas por fuente)", 670, 572, 180, 50, "domain")

A.node("gout", "Destino y consumo", 920, 60, 300, 470, "group", "group", fs=12, bold=True)
A.node("stg", "Staging\nstaging/{Fuente}/*.json", 970, 110, 200, 80, "out", "doc")
A.node("dw", "Base de datos analítica\n(Data Warehouse)", 970, 250, 200, 100, "out", "db")
A.node("dash", "Dashboard\n(Power BI / Web)", 970, 410, 200, 80, "out")

A.node("cfg", "Configuración segura: appsettings.json (sin secretos) + User Secrets / variables de entorno", 250, 670, 640, 34, "cfg", fs=10)
A.node("logs", "Logs: ILogger (consola / Serilog)", 920, 670, 300, 34, "cfg", fs=10)

A.edge("csv", "csvx", "lee CSV", pts=[(230, 150), (230, 372)])
A.edge("sql", "dbx", "SELECT", pts=[(240, 290), (240, 437)])
A.edge("api", "apix", "GET paginado", sa=(200, 445), ta=(290, 495))
A.edge("svc", "csvx", "", dashed=False, sa=(300, 285), ta=(300, 345))
A.edge("dbx", "conn", "", sa=(465, 437), ta=(480, 437))
A.edge("apix", "retry", "", sa=(465, 495), ta=(480, 495))
A.edge("csvx", "stw", "registros válidos de las 3 fuentes", sa=(465, 372), ta=(670, 372))
A.edge("stw", "stg", "JSON", sa=(850, 372), pts=[(915, 372), (915, 140)], ta=(970, 140))
A.edge("stg", "loader", "lee", dashed=True, sa=(970, 175), pts=[(940, 175), (940, 445)], ta=(850, 445))
A.edge("loader", "dw", "carga", dashed=True, sa=(850, 470), pts=[(955, 470), (955, 300)], ta=(970, 300))
A.edge("dw", "dash", "consultas", sa=(1070, 350), ta=(1070, 410))

# ===================== Diagrama de flujo =====================
F = Diagram("Flujo de extracción", 1000, 1080)
F.node("t", "Flujo del proceso de extracción (E de ETL)", 20, 10, 960, 30, "group", "text", fs=16, bold=True)
F.node("ini", "Inicio\n(PeriodicTimer o RunOnce)", 380, 55, 240, 55, "term", "term")
F.node("cfg", "Cargar configuración\n(appsettings + User Secrets)", 380, 140, 240, 55, "step")
F.node("q1", "¿Hay fuentes\nhabilitadas?", 400, 225, 200, 90, "dec", "diamond")
F.node("warn", "Registrar advertencia\n\"sin fuentes\"", 720, 242, 200, 55, "bad")
F.node("par", "Ejecutar extractores en paralelo\n(MaxDegreeOfParallelism)", 360, 345, 280, 55, "step")
F.node("s1", "CsvExtractor\nlee encuestas", 120, 435, 200, 55, "step")
F.node("s2", "DatabaseExtractor\nconsulta reseñas", 400, 435, 200, 55, "step")
F.node("s3", "ApiExtractor\nconsume comentarios", 680, 435, 200, 55, "step")
F.node("rd", "Leer siguiente registro (streaming)", 360, 525, 280, 50, "step")
F.node("q2", "¿Registro\nválido?", 410, 605, 180, 90, "dec", "diamond")
F.node("rej", "Descartar y registrar\nwarning con el motivo", 700, 622, 210, 55, "bad")
F.node("wr", "Escribir en staging\n(archivo .tmp → .json)", 380, 725, 240, 55, "step")
F.node("q3", "¿Error en\nla fuente?", 410, 805, 180, 90, "dec", "diamond")
F.node("err", "LogError + ExtractionResult.Fail\n(las demás fuentes continúan)", 690, 822, 240, 55, "bad")
F.node("sum", "Consolidar resultados y métricas\n(registros, descartes, ms)", 360, 925, 280, 55, "step")
F.node("q4", "¿RunOnce?", 90, 920, 170, 70, "dec", "diamond")
F.node("fin", "Fin", 110, 1015, 130, 45, "term", "term")
F.node("wait", "Esperar\nIntervalMinutes", 80, 140, 190, 55, "step")

F.edge("ini", "cfg"); F.edge("cfg", "q1")
F.edge("q1", "warn", "No"); F.edge("q1", "par", "Sí")
F.edge("par", "s1", pts=[(500, 418), (220, 418)]); F.edge("par", "s2"); F.edge("par", "s3", pts=[(500, 418), (780, 418)])
F.edge("s1", "rd", pts=[(220, 550)]); F.edge("s2", "rd"); F.edge("s3", "rd", pts=[(780, 550)])
F.edge("rd", "q2"); F.edge("q2", "rej", "No"); F.edge("q2", "wr", "Sí")
F.edge("rej", "rd", "siguiente", pts=[(805, 595), (600, 595)], sa=(805, 622), ta=(600, 575))
F.edge("wr", "q3", "fin de datos")
F.edge("q3", "err", "Sí"); F.edge("q3", "sum", "No")
F.edge("err", "sum", pts=[(810, 952)], sa=(810, 877), ta=(640, 952))
F.edge("sum", "q4", sa=(360, 955), ta=(260, 955))
F.edge("q4", "fin", "Sí")
F.edge("q4", "wait", "No", sa=(90, 955), pts=[(50, 955), (50, 167)], ta=(80, 167))
F.edge("wait", "cfg", sa=(270, 167), ta=(380, 167))
F.edge("warn", "sum", pts=[(960, 270), (960, 1000), (500, 1000)], sa=(920, 270), ta=(500, 980))

for d, fname in ((A, "arquitectura"), (F, "flujo_etl")):
    open(f"{OUT}/{fname}.drawio", "w", encoding="utf-8").write(d.drawio())
    d.png(f"{OUT}/{fname}.png")
print("ok")
