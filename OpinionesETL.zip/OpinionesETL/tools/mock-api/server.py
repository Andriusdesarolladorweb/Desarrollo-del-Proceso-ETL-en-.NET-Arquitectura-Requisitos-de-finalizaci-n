"""
API REST de prueba para los comentarios de redes sociales.

Uso:  python server.py            (escucha en http://localhost:5080)
      GET /api/comments?page=1&pageSize=500   con encabezado X-Api-Key: clave-de-prueba
"""
import json
import os
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse

API_KEY = os.environ.get("MOCK_API_KEY", "clave-de-prueba")
DATA = json.load(open(os.path.join(os.path.dirname(__file__), "comments.json"), encoding="utf-8"))


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        url = urlparse(self.path)
        if url.path != "/api/comments":
            return self._send(404, {"error": "No encontrado"})
        if self.headers.get("X-Api-Key") != API_KEY:
            return self._send(401, {"error": "API key inválida"})

        qs = parse_qs(url.query)
        page = max(1, int(qs.get("page", ["1"])[0]))
        size = min(1000, max(1, int(qs.get("pageSize", ["500"])[0])))
        start = (page - 1) * size
        self._send(200, DATA[start:start + size])

    def _send(self, status, body):
        payload = json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)


if __name__ == "__main__":
    print("API de prueba en http://localhost:5080/api/comments")
    HTTPServer(("localhost", 5080), Handler).serve_forever()
