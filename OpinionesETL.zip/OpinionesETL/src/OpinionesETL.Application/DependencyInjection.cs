using Microsoft.Extensions.DependencyInjection;
using OpinionesETL.Application.Abstractions;
using OpinionesETL.Application.Services;

namespace OpinionesETL.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddApplication(this IServiceCollection services)
    {
        services.AddSingleton<IExtractionService, ExtractionService>();
        return services;
    }
}
