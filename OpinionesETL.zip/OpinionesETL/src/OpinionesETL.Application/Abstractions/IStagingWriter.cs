namespace OpinionesETL.Application.Abstractions;

/// <summary>
/// Destino temporal (staging) de los datos extraídos. Recibe un flujo asíncrono
/// para no cargar todo el volumen en memoria.
/// </summary>
public interface IStagingWriter
{
    /// <returns>Ubicación del staging generado y cantidad de registros escritos.</returns>
    Task<StagingWriteResult> WriteAsync<T>(
        string sourceName,
        IAsyncEnumerable<T> records,
        CancellationToken cancellationToken);
}

public sealed record StagingWriteResult(string Location, int RecordsWritten);
