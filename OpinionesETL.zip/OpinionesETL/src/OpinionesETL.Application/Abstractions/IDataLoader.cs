namespace OpinionesETL.Application.Abstractions;

/// <summary>
/// Carga final hacia la base de datos analítica (fase "L" del ETL).
/// Se define aquí para dejar preparada la arquitectura; su implementación
/// corresponde a la siguiente práctica (Transformación y Carga).
/// </summary>
public interface IDataLoader
{
    Task<int> LoadAsync(string stagingLocation, CancellationToken cancellationToken);
}
