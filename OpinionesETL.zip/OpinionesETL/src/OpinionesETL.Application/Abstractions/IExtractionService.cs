using OpinionesETL.Domain.Common;

namespace OpinionesETL.Application.Abstractions;

/// <summary>
/// Caso de uso: ejecutar la extracción de todas las fuentes habilitadas.
/// </summary>
public interface IExtractionService
{
    Task<IReadOnlyList<ExtractionResult>> RunAsync(CancellationToken cancellationToken);
}
