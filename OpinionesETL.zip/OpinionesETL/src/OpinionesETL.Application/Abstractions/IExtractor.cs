using OpinionesETL.Domain.Common;

namespace OpinionesETL.Application.Abstractions;

/// <summary>
/// Contrato común para cualquier fuente de datos. Agregar una fuente nueva
/// solo requiere una nueva implementación de esta interfaz (principio Abierto/Cerrado).
/// </summary>
public interface IExtractor
{
    /// <summary>Nombre lógico de la fuente (ej. "Encuestas", "Reseñas").</summary>
    string SourceName { get; }

    /// <summary>Extrae los datos de la fuente y los deja en el área de staging.</summary>
    Task<ExtractionResult> ExtractAsync(CancellationToken cancellationToken);
}
