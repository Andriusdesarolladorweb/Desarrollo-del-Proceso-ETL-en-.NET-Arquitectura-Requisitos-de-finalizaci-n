namespace OpinionesETL.Application.Options;

/// <summary>
/// Configuración general del proceso ETL (sección "Etl" de appsettings.json).
/// </summary>
public sealed class EtlOptions
{
    public const string SectionName = "Etl";

    /// <summary>Cantidad máxima de fuentes que se extraen en paralelo.</summary>
    public int MaxDegreeOfParallelism { get; set; } = 3;

    /// <summary>Minutos entre una ejecución y la siguiente.</summary>
    public int IntervalMinutes { get; set; } = 60;

    /// <summary>Si es true, el Worker ejecuta una sola vez y se detiene.</summary>
    public bool RunOnce { get; set; }

    /// <summary>Carpeta donde se guardan los archivos de staging.</summary>
    public string StagingPath { get; set; } = "staging";
}
