using System.Diagnostics;
using System.Runtime.CompilerServices;
using Microsoft.Extensions.Logging;
using OpinionesETL.Application.Abstractions;
using OpinionesETL.Domain.Common;

namespace OpinionesETL.Application.Services;

/// <summary>
/// Plantilla (patrón Template Method) que comparten todos los extractores:
/// mide el tiempo con Stopwatch, registra logs, maneja errores y envía los
/// registros al staging. Cada extractor concreto solo implementa ReadAsync.
/// </summary>
public abstract class ExtractorBase<T> : IExtractor
{
    private readonly IStagingWriter _stagingWriter;
    private int _rejected;

    protected ExtractorBase(IStagingWriter stagingWriter, ILogger logger)
    {
        _stagingWriter = stagingWriter;
        Logger = logger;
    }

    protected ILogger Logger { get; }

    public abstract string SourceName { get; }

    /// <summary>Lee la fuente como flujo asíncrono (streaming) de registros.</summary>
    protected abstract IAsyncEnumerable<T> ReadAsync(CancellationToken cancellationToken);

    /// <summary>Los extractores llaman este método cuando descartan un registro inválido.</summary>
    protected void Reject(string reason)
    {
        Interlocked.Increment(ref _rejected);
        Logger.LogWarning("[{Source}] Registro descartado: {Reason}", SourceName, reason);
    }

    public async Task<ExtractionResult> ExtractAsync(CancellationToken cancellationToken)
    {
        _rejected = 0;
        var stopwatch = Stopwatch.StartNew();
        Logger.LogInformation("[{Source}] Iniciando extracción...", SourceName);

        try
        {
            var result = await _stagingWriter.WriteAsync(
                SourceName, ReadWithCancellation(cancellationToken), cancellationToken);

            stopwatch.Stop();
            Logger.LogInformation(
                "[{Source}] Extracción completada: {Count} registros, {Rejected} descartados, {Elapsed} ms -> {Location}",
                SourceName, result.RecordsWritten, _rejected, stopwatch.ElapsedMilliseconds, result.Location);

            return ExtractionResult.Ok(SourceName, result.RecordsWritten, _rejected, stopwatch.Elapsed, result.Location);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            Logger.LogWarning("[{Source}] Extracción cancelada.", SourceName);
            throw;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            Logger.LogError(ex, "[{Source}] Error durante la extracción tras {Elapsed} ms", SourceName, stopwatch.ElapsedMilliseconds);
            return ExtractionResult.Fail(SourceName, stopwatch.Elapsed, ex.Message);
        }
    }

    private async IAsyncEnumerable<T> ReadWithCancellation([EnumeratorCancellation] CancellationToken cancellationToken)
    {
        await foreach (var record in ReadAsync(cancellationToken).WithCancellation(cancellationToken))
        {
            yield return record;
        }
    }
}
