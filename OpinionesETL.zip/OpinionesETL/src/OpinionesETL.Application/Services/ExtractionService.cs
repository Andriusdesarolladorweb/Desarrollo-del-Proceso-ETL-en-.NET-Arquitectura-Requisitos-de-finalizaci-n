using System.Collections.Concurrent;
using System.Diagnostics;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using OpinionesETL.Application.Abstractions;
using OpinionesETL.Application.Options;
using OpinionesETL.Domain.Common;

namespace OpinionesETL.Application.Services;

/// <summary>
/// Orquesta la extracción: ejecuta en paralelo todos los extractores registrados
/// (solo las fuentes habilitadas en la configuración) y consolida los resultados.
/// Un fallo en una fuente no detiene a las demás.
/// </summary>
public sealed class ExtractionService : IExtractionService
{
    private readonly IEnumerable<IExtractor> _extractors;
    private readonly EtlOptions _options;
    private readonly ILogger<ExtractionService> _logger;

    public ExtractionService(
        IEnumerable<IExtractor> extractors,
        IOptions<EtlOptions> options,
        ILogger<ExtractionService> logger)
    {
        _extractors = extractors;
        _options = options.Value;
        _logger = logger;
    }

    public async Task<IReadOnlyList<ExtractionResult>> RunAsync(CancellationToken cancellationToken)
    {
        var extractors = _extractors.ToList();
        if (extractors.Count == 0)
        {
            _logger.LogWarning("No hay fuentes habilitadas en la configuración.");
            return Array.Empty<ExtractionResult>();
        }

        var stopwatch = Stopwatch.StartNew();
        var results = new ConcurrentBag<ExtractionResult>();

        _logger.LogInformation(
            "Extracción iniciada para {Count} fuente(s) con paralelismo máximo de {Dop}.",
            extractors.Count, _options.MaxDegreeOfParallelism);

        await Parallel.ForEachAsync(
            extractors,
            new ParallelOptions
            {
                MaxDegreeOfParallelism = Math.Max(1, _options.MaxDegreeOfParallelism),
                CancellationToken = cancellationToken
            },
            async (extractor, ct) => results.Add(await extractor.ExtractAsync(ct)));

        stopwatch.Stop();

        var ordered = results.OrderBy(r => r.SourceName).ToList();
        _logger.LogInformation(
            "Extracción finalizada en {Elapsed} ms. Fuentes OK: {Ok}/{Total}. Registros totales: {Records}.",
            stopwatch.ElapsedMilliseconds,
            ordered.Count(r => r.Success),
            ordered.Count,
            ordered.Sum(r => r.RecordsExtracted));

        return ordered;
    }
}
