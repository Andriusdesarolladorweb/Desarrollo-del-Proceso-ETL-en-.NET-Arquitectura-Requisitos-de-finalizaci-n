namespace OpinionesETL.Domain.Common;

/// <summary>
/// Resultado de la extracción de una fuente. Permite medir rendimiento y auditar cada ejecución.
/// </summary>
public sealed record ExtractionResult(
    string SourceName,
    bool Success,
    int RecordsExtracted,
    int RecordsRejected,
    TimeSpan Duration,
    string? StagingLocation,
    string? ErrorMessage)
{
    public static ExtractionResult Ok(string source, int extracted, int rejected, TimeSpan duration, string location)
        => new(source, true, extracted, rejected, duration, location, null);

    public static ExtractionResult Fail(string source, TimeSpan duration, string error)
        => new(source, false, 0, 0, duration, null, error);
}
