namespace OpinionesETL.Domain.Entities;

/// <summary>
/// Respuesta de una encuesta interna de satisfacción (fuente: archivo CSV).
/// </summary>
public sealed class SurveyResponse
{
    public int IdOpinion { get; set; }
    public int IdCliente { get; set; }
    public int IdProducto { get; set; }
    public DateTime Fecha { get; set; }
    public string Comentario { get; set; } = string.Empty;
    public string Clasificacion { get; set; } = string.Empty;
    public int PuntajeSatisfaccion { get; set; }
    public string Fuente { get; set; } = string.Empty;
}
