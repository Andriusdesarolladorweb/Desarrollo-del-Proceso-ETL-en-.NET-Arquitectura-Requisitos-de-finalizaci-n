namespace OpinionesETL.Domain.Entities;

/// <summary>
/// Reseña publicada en el sitio web (fuente: base de datos relacional).
/// </summary>
public sealed class WebReview
{
    public string IdReview { get; set; } = string.Empty;
    public int IdCliente { get; set; }
    public int IdProducto { get; set; }
    public DateTime Fecha { get; set; }
    public string Comentario { get; set; } = string.Empty;
    public int Rating { get; set; }
}
