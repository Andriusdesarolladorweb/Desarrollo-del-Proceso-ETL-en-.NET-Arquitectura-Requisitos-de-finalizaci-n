namespace OpinionesETL.Domain.Entities;

/// <summary>
/// Comentario obtenido de redes sociales (fuente: API REST).
/// </summary>
public sealed class SocialComment
{
    public string IdComment { get; set; } = string.Empty;
    public int? IdCliente { get; set; }
    public int IdProducto { get; set; }
    public string Fuente { get; set; } = string.Empty;
    public DateTime Fecha { get; set; }
    public string Comentario { get; set; } = string.Empty;
}
