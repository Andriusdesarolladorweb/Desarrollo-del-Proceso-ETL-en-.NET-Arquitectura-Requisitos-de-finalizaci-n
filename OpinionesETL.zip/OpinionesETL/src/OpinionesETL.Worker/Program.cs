using OpinionesETL.Application;
using OpinionesETL.Infrastructure;
using OpinionesETL.Worker;

// Las rutas relativas (data/, staging/) se resuelven desde la carpeta del ejecutable.
// Es necesario si el Worker se instala como Servicio de Windows, que arranca en System32.
Directory.SetCurrentDirectory(AppContext.BaseDirectory);

// Host.CreateApplicationBuilder carga, en este orden: appsettings.json,
// appsettings.{Environment}.json, User Secrets (en Development) y variables de entorno.
// Así las credenciales nunca quedan en el código ni en el repositorio.
var builder = Host.CreateApplicationBuilder(args);

builder.Services
    .AddApplication()
    .AddInfrastructure(builder.Configuration);

builder.Services.AddHostedService<Worker>();

var host = builder.Build();
host.Run();
