using Microsoft.Extensions.Options;
using OpinionesETL.Application.Abstractions;
using OpinionesETL.Application.Options;

namespace OpinionesETL.Worker;

/// <summary>
/// Servicio en segundo plano que dispara la extracción periódicamente.
/// Solo coordina la ejecución; toda la lógica vive en las capas Application e Infrastructure.
/// </summary>
public sealed class Worker : BackgroundService
{
    private readonly IExtractionService _extractionService;
    private readonly IHostApplicationLifetime _lifetime;
    private readonly EtlOptions _options;
    private readonly ILogger<Worker> _logger;

    public Worker(
        IExtractionService extractionService,
        IHostApplicationLifetime lifetime,
        IOptions<EtlOptions> options,
        ILogger<Worker> logger)
    {
        _extractionService = extractionService;
        _lifetime = lifetime;
        _options = options.Value;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Worker ETL iniciado. Modo: {Mode}.",
            _options.RunOnce ? "ejecución única" : $"cada {_options.IntervalMinutes} min");

        using var timer = new PeriodicTimer(TimeSpan.FromMinutes(Math.Max(1, _options.IntervalMinutes)));

        try
        {
            do
            {
                await RunCycleAsync(stoppingToken);

                if (_options.RunOnce)
                {
                    _lifetime.StopApplication();
                    return;
                }
            }
            while (await timer.WaitForNextTickAsync(stoppingToken));
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
        {
            _logger.LogInformation("Worker ETL detenido.");
        }
    }

    private async Task RunCycleAsync(CancellationToken stoppingToken)
    {
        try
        {
            var results = await _extractionService.RunAsync(stoppingToken);

            foreach (var r in results)
            {
                if (r.Success)
                    _logger.LogInformation("  ✔ {Source}: {Count} registros ({Rejected} descartados) en {Ms} ms",
                        r.SourceName, r.RecordsExtracted, r.RecordsRejected, (long)r.Duration.TotalMilliseconds);
                else
                    _logger.LogError("  ✘ {Source}: {Error}", r.SourceName, r.ErrorMessage);
            }
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            // Un error inesperado no debe tumbar el servicio; se reintenta en el próximo ciclo.
            _logger.LogCritical(ex, "Fallo inesperado en el ciclo de extracción.");
        }
    }
}
