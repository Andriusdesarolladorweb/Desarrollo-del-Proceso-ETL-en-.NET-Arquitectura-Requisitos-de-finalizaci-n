using System.Data.Common;

namespace OpinionesETL.Infrastructure.Persistence;

/// <summary>
/// Abstrae la creación de conexiones para no acoplar los extractores a un motor específico.
/// </summary>
public interface IDbConnectionFactory
{
    DbConnection CreateConnection();
}
