using System.Data.Common;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using OpinionesETL.Infrastructure.Options;

namespace OpinionesETL.Infrastructure.Persistence;

/// <summary>
/// Crea conexiones a SQL Server. La cadena se lee de "ConnectionStrings", que en
/// desarrollo viene de User Secrets y en producción de variables de entorno.
/// </summary>
public sealed class SqlConnectionFactory : IDbConnectionFactory
{
    private readonly string _connectionString;

    public SqlConnectionFactory(IConfiguration configuration, IOptions<SourcesOptions> options)
    {
        var name = options.Value.Database.ConnectionStringName;
        _connectionString = configuration.GetConnectionString(name)
            ?? throw new InvalidOperationException(
                $"Falta la cadena de conexión '{name}'. Configúrela con: dotnet user-secrets set \"ConnectionStrings:{name}\" \"...\"");
    }

    public DbConnection CreateConnection() => new SqlConnection(_connectionString);
}
