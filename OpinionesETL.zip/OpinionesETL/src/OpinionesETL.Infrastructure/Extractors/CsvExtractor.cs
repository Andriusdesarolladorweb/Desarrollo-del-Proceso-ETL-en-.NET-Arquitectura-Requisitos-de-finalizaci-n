using System.Globalization;
using System.Runtime.CompilerServices;
using CsvHelper;
using CsvHelper.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using OpinionesETL.Application.Abstractions;
using OpinionesETL.Application.Services;
using OpinionesETL.Domain.Entities;
using OpinionesETL.Infrastructure.Options;

namespace OpinionesETL.Infrastructure.Extractors;

/// <summary>
/// Extrae las encuestas internas desde un archivo CSV usando CsvHelper.
/// Lee fila por fila (streaming) y descarta las filas inválidas sin detener el proceso.
/// </summary>
public sealed class CsvExtractor : ExtractorBase<SurveyResponse>
{
    private readonly CsvSourceOptions _options;

    public CsvExtractor(IOptions<SourcesOptions> options, IStagingWriter stagingWriter, ILogger<CsvExtractor> logger)
        : base(stagingWriter, logger)
    {
        _options = options.Value.Csv;
    }

    public override string SourceName => "EncuestasCsv";

    protected override async IAsyncEnumerable<SurveyResponse> ReadAsync(
        [EnumeratorCancellation] CancellationToken cancellationToken)
    {
        if (!File.Exists(_options.FilePath))
        {
            throw new FileNotFoundException($"No se encontró el archivo CSV de encuestas: {_options.FilePath}");
        }

        var config = new CsvConfiguration(CultureInfo.InvariantCulture)
        {
            Delimiter = _options.Delimiter,
            HasHeaderRecord = true,
            TrimOptions = TrimOptions.Trim,
            MissingFieldFound = null,
            HeaderValidated = null,
            BadDataFound = args => Reject($"Dato mal formado en la fila {args.Context.Parser?.Row}")
        };

        await using var stream = new FileStream(
            _options.FilePath, FileMode.Open, FileAccess.Read, FileShare.Read, bufferSize: 81920, useAsync: true);
        using var reader = new StreamReader(stream);
        using var csv = new CsvReader(reader, config);
        csv.Context.RegisterClassMap(new SurveyResponseMap(_options.DateFormat));

        await csv.ReadAsync();
        csv.ReadHeader();

        while (await csv.ReadAsync())
        {
            cancellationToken.ThrowIfCancellationRequested();

            SurveyResponse? record;
            try
            {
                record = csv.GetRecord<SurveyResponse>();
            }
            catch (CsvHelper.TypeConversion.TypeConverterException ex)
            {
                Reject($"Fila {csv.Parser.Row}: valor '{ex.Text}' inválido en la columna {ex.MemberMapData?.Member?.Name}");
                continue;
            }
            catch (CsvHelperException ex)
            {
                Reject($"Fila {csv.Parser.Row}: {FirstLine(ex.Message)}");
                continue;
            }

            var error = Validate(record);
            if (error is not null)
            {
                Reject($"Fila {csv.Parser.Row}: {error}");
                continue;
            }

            yield return record!;
        }
    }

    private static string? Validate(SurveyResponse? r)
    {
        if (r is null) return "fila vacía";
        if (r.IdOpinion <= 0) return "IdOpinion inválido";
        if (r.IdCliente <= 0) return "IdCliente inválido";
        if (r.IdProducto <= 0) return "IdProducto inválido";
        if (string.IsNullOrWhiteSpace(r.Comentario)) return "comentario vacío";
        if (r.PuntajeSatisfaccion is < 1 or > 5) return $"puntaje fuera de rango ({r.PuntajeSatisfaccion})";
        return null;
    }

    private static string FirstLine(string message) =>
        message.Split('\n', 2)[0].Trim();

    /// <summary>Mapeo de columnas del CSV a la entidad (acepta encabezados con o sin tilde).</summary>
    private sealed class SurveyResponseMap : ClassMap<SurveyResponse>
    {
        public SurveyResponseMap(string dateFormat)
        {
            Map(m => m.IdOpinion).Name("IdOpinion");
            Map(m => m.IdCliente).Name("IdCliente");
            Map(m => m.IdProducto).Name("IdProducto");
            Map(m => m.Fecha).Name("Fecha").TypeConverterOption.Format(dateFormat);
            Map(m => m.Comentario).Name("Comentario");
            Map(m => m.Clasificacion).Name("Clasificación", "Clasificacion");
            Map(m => m.PuntajeSatisfaccion).Name("PuntajeSatisfacción", "PuntajeSatisfaccion");
            Map(m => m.Fuente).Name("Fuente");
        }
    }
}
