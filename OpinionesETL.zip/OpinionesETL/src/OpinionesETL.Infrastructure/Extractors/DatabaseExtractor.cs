using System.Data;
using System.Data.Common;
using System.Runtime.CompilerServices;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using OpinionesETL.Application.Abstractions;
using OpinionesETL.Application.Services;
using OpinionesETL.Domain.Entities;
using OpinionesETL.Infrastructure.Options;
using OpinionesETL.Infrastructure.Persistence;

namespace OpinionesETL.Infrastructure.Extractors;

/// <summary>
/// Extrae las reseñas web desde la base de datos relacional con ADO.NET.
/// Usa DbDataReader para leer en streaming, sin cargar toda la tabla en memoria.
/// </summary>
public sealed class DatabaseExtractor : ExtractorBase<WebReview>
{
    private readonly IDbConnectionFactory _connectionFactory;
    private readonly DatabaseSourceOptions _options;

    public DatabaseExtractor(
        IDbConnectionFactory connectionFactory,
        IOptions<SourcesOptions> options,
        IStagingWriter stagingWriter,
        ILogger<DatabaseExtractor> logger)
        : base(stagingWriter, logger)
    {
        _connectionFactory = connectionFactory;
        _options = options.Value.Database;
    }

    public override string SourceName => "ResenasBd";

    protected override async IAsyncEnumerable<WebReview> ReadAsync(
        [EnumeratorCancellation] CancellationToken cancellationToken)
    {
        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenAsync(cancellationToken);

        await using var command = connection.CreateCommand();
        command.CommandText = _options.Query;
        command.CommandType = CommandType.Text;
        command.CommandTimeout = _options.CommandTimeoutSeconds;

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);

        var idReview = reader.GetOrdinal("IdReview");
        var idCliente = reader.GetOrdinal("IdCliente");
        var idProducto = reader.GetOrdinal("IdProducto");
        var fecha = reader.GetOrdinal("Fecha");
        var comentario = reader.GetOrdinal("Comentario");
        var rating = reader.GetOrdinal("Rating");

        while (await reader.ReadAsync(cancellationToken))
        {
            if (reader.IsDBNull(comentario) || reader.IsDBNull(rating))
            {
                Reject($"Reseña {reader.GetValue(idReview)} sin comentario o rating");
                continue;
            }

            yield return new WebReview
            {
                IdReview = Convert.ToString(reader.GetValue(idReview))!,
                IdCliente = Convert.ToInt32(reader.GetValue(idCliente)),
                IdProducto = Convert.ToInt32(reader.GetValue(idProducto)),
                Fecha = reader.GetDateTime(fecha),
                Comentario = reader.GetString(comentario).Trim(),
                Rating = Convert.ToInt32(reader.GetValue(rating))
            };
        }
    }
}
