using System.Runtime.CompilerServices;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using OpinionesETL.Application.Abstractions;
using OpinionesETL.Application.Services;
using OpinionesETL.Domain.Entities;
using OpinionesETL.Infrastructure.Options;

namespace OpinionesETL.Infrastructure.Extractors;

/// <summary>
/// Consume la API REST de comentarios de redes sociales con IHttpClientFactory.
/// Recorre la API por páginas y deserializa la respuesta en streaming.
/// </summary>
public sealed class ApiExtractor : ExtractorBase<SocialComment>
{
    public const string HttpClientName = "ComentariosApi";

    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ApiSourceOptions _options;

    public ApiExtractor(
        IHttpClientFactory httpClientFactory,
        IOptions<SourcesOptions> options,
        IStagingWriter stagingWriter,
        ILogger<ApiExtractor> logger)
        : base(stagingWriter, logger)
    {
        _httpClientFactory = httpClientFactory;
        _options = options.Value.Api;
    }

    public override string SourceName => "ComentariosApi";

    protected override async IAsyncEnumerable<SocialComment> ReadAsync(
        [EnumeratorCancellation] CancellationToken cancellationToken)
    {
        var client = _httpClientFactory.CreateClient(HttpClientName);

        for (var page = 1; page <= _options.MaxPages; page++)
        {
            var url = $"{_options.Endpoint}?page={page}&pageSize={_options.PageSize}";
            Logger.LogDebug("[{Source}] GET {Url}", SourceName, url);

            using var response = await client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, cancellationToken);
            response.EnsureSuccessStatusCode();

            await using var body = await response.Content.ReadAsStreamAsync(cancellationToken);
            var items = await JsonSerializer.DeserializeAsync<List<SocialComment>>(body, JsonOptions, cancellationToken)
                        ?? new List<SocialComment>();

            foreach (var item in items)
            {
                if (string.IsNullOrWhiteSpace(item.IdComment) || string.IsNullOrWhiteSpace(item.Comentario))
                {
                    Reject($"Comentario sin id o sin texto (página {page})");
                    continue;
                }

                item.Comentario = item.Comentario.Trim();
                yield return item;
            }

            if (items.Count < _options.PageSize)
            {
                yield break; // última página
            }
        }

        Logger.LogWarning("[{Source}] Se alcanzó el límite de {MaxPages} páginas.", SourceName, _options.MaxPages);
    }
}
