using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using OpinionesETL.Application.Abstractions;
using OpinionesETL.Application.Options;
using OpinionesETL.Infrastructure.Extractors;
using OpinionesETL.Infrastructure.Http;
using OpinionesETL.Infrastructure.Options;
using OpinionesETL.Infrastructure.Persistence;
using OpinionesETL.Infrastructure.Staging;

namespace OpinionesETL.Infrastructure;

public static class DependencyInjection
{
    /// <summary>
    /// Registra la infraestructura. Solo se registran los extractores de las fuentes
    /// con "Enabled": true, así que agregar o quitar una fuente es un cambio de configuración.
    /// </summary>
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<EtlOptions>(configuration.GetSection(EtlOptions.SectionName));
        services.Configure<SourcesOptions>(configuration.GetSection(SourcesOptions.SectionName));

        var sources = configuration.GetSection(SourcesOptions.SectionName).Get<SourcesOptions>() ?? new SourcesOptions();

        services.AddSingleton<IStagingWriter, JsonFileStagingWriter>();

        if (sources.Csv.Enabled)
        {
            services.AddSingleton<IExtractor, CsvExtractor>();
        }

        if (sources.Database.Enabled)
        {
            services.AddSingleton<IDbConnectionFactory, SqlConnectionFactory>();
            services.AddSingleton<IExtractor, DatabaseExtractor>();
        }

        if (sources.Api.Enabled)
        {
            services.AddTransient<RetryHandler>();
            services.AddHttpClient(ApiExtractor.HttpClientName, client =>
                {
                    client.BaseAddress = new Uri(sources.Api.BaseUrl);
                    client.Timeout = TimeSpan.FromSeconds(sources.Api.TimeoutSeconds);
                    if (!string.IsNullOrWhiteSpace(sources.Api.ApiKey))
                    {
                        client.DefaultRequestHeaders.Add(sources.Api.ApiKeyHeader, sources.Api.ApiKey);
                    }
                })
                .AddHttpMessageHandler<RetryHandler>();

            services.AddSingleton<IExtractor, ApiExtractor>();
        }

        return services;
    }
}
