namespace OpinionesETL.Infrastructure.Options;

/// <summary>
/// Configuración modular de las fuentes (sección "Sources" de appsettings.json).
/// Cada fuente se activa o desactiva con "Enabled" sin tocar el código.
/// </summary>
public sealed class SourcesOptions
{
    public const string SectionName = "Sources";

    public CsvSourceOptions Csv { get; set; } = new();
    public DatabaseSourceOptions Database { get; set; } = new();
    public ApiSourceOptions Api { get; set; } = new();
}

public sealed class CsvSourceOptions
{
    public bool Enabled { get; set; }
    public string FilePath { get; set; } = string.Empty;
    public string Delimiter { get; set; } = ",";
    public string DateFormat { get; set; } = "yyyy-MM-dd";
}

public sealed class DatabaseSourceOptions
{
    public bool Enabled { get; set; }

    /// <summary>Nombre de la cadena en "ConnectionStrings". La cadena real NO va en appsettings.json.</summary>
    public string ConnectionStringName { get; set; } = "SourceDb";

    public string Query { get; set; } = string.Empty;
    public int CommandTimeoutSeconds { get; set; } = 60;
}

public sealed class ApiSourceOptions
{
    public bool Enabled { get; set; }
    public string BaseUrl { get; set; } = string.Empty;
    public string Endpoint { get; set; } = "api/comments";
    public int PageSize { get; set; } = 500;
    public int MaxPages { get; set; } = 1000;
    public int TimeoutSeconds { get; set; } = 30;
    public int MaxRetries { get; set; } = 3;
    public string ApiKeyHeader { get; set; } = "X-Api-Key";

    /// <summary>Se toma de User Secrets o variables de entorno, nunca del repositorio.</summary>
    public string? ApiKey { get; set; }
}
