using System.Runtime.CompilerServices;
using System.Text.Encodings.Web;
using System.Text.Json;
using Microsoft.Extensions.Options;
using OpinionesETL.Application.Abstractions;
using OpinionesETL.Application.Options;

namespace OpinionesETL.Infrastructure.Staging;

/// <summary>
/// Guarda los datos extraídos en archivos JSON temporales (área de staging):
/// staging/{Fuente}/{Fuente}_{fecha}.json
/// Escribe en streaming a un archivo .tmp y lo renombra al terminar, para que
/// la fase de transformación nunca lea un archivo incompleto.
/// </summary>
public sealed class JsonFileStagingWriter : IStagingWriter
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping // conserva tildes y ñ legibles
    };

    private readonly EtlOptions _options;

    public JsonFileStagingWriter(IOptions<EtlOptions> options)
    {
        _options = options.Value;
    }

    public async Task<StagingWriteResult> WriteAsync<T>(
        string sourceName, IAsyncEnumerable<T> records, CancellationToken cancellationToken)
    {
        var directory = Path.Combine(_options.StagingPath, sourceName);
        Directory.CreateDirectory(directory);

        var finalPath = Path.Combine(directory, $"{sourceName}_{DateTime.Now:yyyyMMdd_HHmmss_fff}.json");
        var tempPath = finalPath + ".tmp";
        var counter = new Counter();

        try
        {
            await using (var stream = new FileStream(
                tempPath, FileMode.Create, FileAccess.Write, FileShare.None, bufferSize: 81920, useAsync: true))
            {
                await JsonSerializer.SerializeAsync(stream, Count(records, counter, cancellationToken), JsonOptions, cancellationToken);
            }

            File.Move(tempPath, finalPath, overwrite: true);
        }
        catch
        {
            if (File.Exists(tempPath)) File.Delete(tempPath);
            throw;
        }

        return new StagingWriteResult(Path.GetFullPath(finalPath), counter.Value);
    }

    private static async IAsyncEnumerable<T> Count<T>(
        IAsyncEnumerable<T> source, Counter counter, [EnumeratorCancellation] CancellationToken cancellationToken)
    {
        await foreach (var item in source.WithCancellation(cancellationToken))
        {
            counter.Value++;
            yield return item;
        }
    }

    private sealed class Counter
    {
        public int Value;
    }
}
