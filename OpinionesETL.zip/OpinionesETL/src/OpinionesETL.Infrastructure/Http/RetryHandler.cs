using System.Net;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using OpinionesETL.Infrastructure.Options;

namespace OpinionesETL.Infrastructure.Http;

/// <summary>
/// Reintenta las llamadas HTTP ante fallos transitorios (errores 5xx, 408, 429 o de red)
/// con espera exponencial: 1s, 2s, 4s...
/// </summary>
public sealed class RetryHandler : DelegatingHandler
{
    private readonly int _maxRetries;
    private readonly ILogger<RetryHandler> _logger;

    public RetryHandler(IOptions<SourcesOptions> options, ILogger<RetryHandler> logger)
    {
        _maxRetries = Math.Max(0, options.Value.Api.MaxRetries);
        _logger = logger;
    }

    protected override async Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request, CancellationToken cancellationToken)
    {
        for (var attempt = 0; ; attempt++)
        {
            try
            {
                var response = await base.SendAsync(request, cancellationToken);
                if (!IsTransient(response.StatusCode) || attempt >= _maxRetries)
                {
                    return response;
                }

                _logger.LogWarning("HTTP {Status} en {Url}. Reintento {Attempt}/{Max}.",
                    (int)response.StatusCode, request.RequestUri, attempt + 1, _maxRetries);
                response.Dispose();
            }
            catch (HttpRequestException ex) when (attempt < _maxRetries)
            {
                _logger.LogWarning("Error de red en {Url}: {Message}. Reintento {Attempt}/{Max}.",
                    request.RequestUri, ex.Message, attempt + 1, _maxRetries);
            }

            await Task.Delay(TimeSpan.FromSeconds(Math.Pow(2, attempt)), cancellationToken);
        }
    }

    private static bool IsTransient(HttpStatusCode status) =>
        (int)status >= 500 || status is HttpStatusCode.RequestTimeout or HttpStatusCode.TooManyRequests;
}
