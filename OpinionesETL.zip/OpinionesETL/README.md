# OpinionesETL: Extracción (E de ETL) en .NET 8

Worker Service en .NET 8 que extrae opiniones de clientes desde tres fuentes y las deja en un área de *staging*. Es la base del proceso ETL hacia la base de datos analítica.

| Fuente | Extractor | Tecnología | Staging generado |
|---|---|---|---|
| Encuestas internas (CSV) | `CsvExtractor` | CsvHelper | `staging/EncuestasCsv/*.json` |
| Reseñas web (SQL Server) | `DatabaseExtractor` | ADO.NET (`Microsoft.Data.SqlClient`) | `staging/ResenasBd/*.json` |
| Comentarios de redes (API REST) | `ApiExtractor` | `IHttpClientFactory` | `staging/ComentariosApi/*.json` |

## Arquitectura (Clean Architecture)

```
src/
├── OpinionesETL.Domain          Entidades (SurveyResponse, WebReview, SocialComment) y ExtractionResult
├── OpinionesETL.Application     Contratos (IExtractor, IStagingWriter, IDataLoader), ExtractorBase y ExtractionService
├── OpinionesETL.Infrastructure  Extractores concretos, staging en JSON, conexión SQL, HttpClient con reintentos
└── OpinionesETL.Worker          Host, BackgroundService y configuración (appsettings.json)
```

Las dependencias apuntan hacia adentro: Worker → Infrastructure → Application → Domain.

## Cómo ejecutar

1. **Base de datos fuente:** ejecuta `database/01_fuente_webreviews.sql` en SQL Server.
2. **Credenciales:** guárdalas con User Secrets. Nunca van en `appsettings.json`.
   ```bash
   cd src/OpinionesETL.Worker
   dotnet user-secrets set "ConnectionStrings:SourceDb" "Server=localhost;Database=OpinionesFuenteDB;User Id=etl_reader;Password=...;TrustServerCertificate=True"
   dotnet user-secrets set "Sources:Api:ApiKey" "clave-de-prueba"
   ```
3. **API de prueba (opcional):** ejecuta `python tools/mock-api/server.py` y, en `appsettings.json`, pon `Sources:Api:BaseUrl` en `http://localhost:5080/`.
4. **Ejecutar:**
   ```bash
   dotnet run --project src/OpinionesETL.Worker
   ```
   En `Development`, el worker se ejecuta una sola vez (`Etl:RunOnce = true`). En producción se repite cada `Etl:IntervalMinutes` minutos.

## Agregar una nueva fuente

1. Crea una entidad en `Domain/Entities`.
2. Crea `NuevaFuenteExtractor : ExtractorBase<NuevaEntidad>` e implementa solo `ReadAsync`.
3. Agrega su sección en `Sources` y regístrala en `Infrastructure/DependencyInjection.cs`.

No hay que modificar el orquestador ni el Worker.

## Configuración principal

| Clave | Descripción |
|---|---|
| `Etl:MaxDegreeOfParallelism` | Cantidad de fuentes que se extraen en paralelo |
| `Etl:IntervalMinutes` / `Etl:RunOnce` | Frecuencia de ejecución |
| `Etl:StagingPath` | Carpeta de staging |
| `Sources:{Csv,Database,Api}:Enabled` | Activa o desactiva cada fuente |
